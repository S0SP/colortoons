import React, { useCallback, useState, useEffect } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    Image,
    ScrollView,
    useWindowDimensions,
    Alert,
} from 'react-native';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useUserStore } from '../store';
import { usePaintingStore, SavedPainting } from '../store/usePaintingStore';
import { CurrencyDisplay } from '../components/CurrencyDisplay';
import { DailyRewardModal } from '../components/DailyRewardModal';
import { CreateNewButton } from '../components/CreateNewButton';
import { COLORS, FONTS, SPACING, SHADOWS } from '../theme';
import { AudioManager } from '../services/AudioManager';

const BANNER_HEIGHT = 360;

// Jump Back In Card Component
const JumpBackInCard = ({
    painting,
    onPress,
    onDelete,
}: {
    painting: SavedPainting;
    onPress: () => void;
    onDelete: () => void;
}) => {
    const progressPercent = Math.round(painting.progress * 100);

    const handleLongPress = () => {
        Alert.alert(
            'Delete Painting?',
            `Remove "${painting.title}" from your saved paintings?`,
            [
                { text: 'Cancel', style: 'cancel' },
                { text: 'Delete', style: 'destructive', onPress: onDelete },
            ]
        );
    };

    return (
        <TouchableOpacity
            style={styles.artCard}
            onPress={onPress}
            onLongPress={handleLongPress}
            activeOpacity={0.9}
        >
            {/* Thumbnail */}
            <View style={styles.artCardImageContainer}>
                {painting.thumbnailB64 ? (
                    <Image
                        source={{ uri: `data:image/jpeg;base64,${painting.thumbnailB64}` }}
                        style={styles.artCardImage as any}
                        resizeMode="cover"
                    />
                ) : (
                    <View style={styles.artCardPlaceholder}>
                        <Text style={{ fontSize: 30 }}>🎨</Text>
                    </View>
                )}

                {/* Progress Badge */}
                <View style={styles.progressBadge}>
                    <Text style={styles.progressBadgeText}>{progressPercent}%</Text>
                </View>
            </View>

            {/* Title */}
            <Text style={styles.artCardTitle} numberOfLines={1}>
                {painting.title}
            </Text>

            {/* Progress Bar */}
            <View style={styles.progressBarBg}>
                <View
                    style={[
                        styles.progressBarFill,
                        { width: `${progressPercent}%` },
                    ]}
                />
            </View>

            {/* Continue Button */}
            <View style={styles.continueButton}>
                <Icon name="play" size={14} color="#FFF" />
                <Text style={styles.continueText}>Continue</Text>
            </View>
        </TouchableOpacity>
    );
};

export const HomeScreen = () => {
    const { coins, streak } = useUserStore();
    const { getRecentPaintings, deletePainting } = usePaintingStore();
    const navigation = useNavigation();
    const { width } = useWindowDimensions();
    const bannerWidth = width - SPACING.m * 2;
    const [showDailyReward, setShowDailyReward] = useState(false);
    const [isMuted, setIsMuted] = useState(AudioManager.muted);
    const { canClaimDailyReward, checkEnergyRefill } = useUserStore();

    const recentPaintings = getRecentPaintings(10);

    // Check for daily reward on mount
    useEffect(() => {
        checkEnergyRefill(); // Refill energy if time has passed

        // Show daily reward popup if available
        if (canClaimDailyReward()) {
            setTimeout(() => setShowDailyReward(true), 500);
        }
    }, []);
    // Play app music when screen is focused
    useFocusEffect(
        useCallback(() => {
            AudioManager.initialize().then(() => {
                AudioManager.playAppMusic();
            });
            return () => { };
        }, [])
    );

    const handleResumePainting = (painting: SavedPainting) => {
        // Navigate directly to Game with saved data
        AudioManager.playGameMusic();
        (navigation as any).navigate('Game', {
            data: painting.backendData,
            title: painting.title,
            savedPaintingId: painting.id,
            resumeFilledRegions: painting.filledRegions,
        });
    };

    const handleDeletePainting = (id: string) => {
        deletePainting(id);
    };

    return (
        <SafeAreaView style={styles.container} edges={['top']}>
            {/* Header */}
            <View style={styles.header}>
                <View style={styles.avatarContainer}>
                    <Image
                        source={require('../assets/fox_avatar.png')}
                        style={styles.avatar as any}
                    />
                </View>

                <View style={styles.statsContainer}>
                    <CurrencyDisplay showStreak showEnergy />

                    {/* Music Toggle */}
                    <TouchableOpacity
                        style={styles.statPill}
                        onPress={() => {
                            const newMutedState = AudioManager.toggleMute();
                            setIsMuted(newMutedState);
                        }}
                    >
                        <Icon
                            name={isMuted ? 'volume-off' : 'volume-high'}
                            size={20}
                            color="#64748B"
                        />
                    </TouchableOpacity>
                </View>
            </View>

            <ScrollView
                contentContainerStyle={styles.scrollContent}
                showsVerticalScrollIndicator={false}
            >
                {/* Main Banner */}
                <View style={[styles.bannerContainer, { height: BANNER_HEIGHT }]}>
                    <Image
                        source={require('../assets/fox_banner_full.png')}
                        style={styles.bannerFullImage as any}
                        resizeMode="cover"
                    />

                    <View style={styles.createButtonContainer}>
                        <CreateNewButton
                            width={bannerWidth - 40}
                            onPress={() => (navigation as any).navigate('Magic')}
                        />
                    </View>
                </View>

                {/* Jump Back In */}
                {recentPaintings.length > 0 && (
                    <>
                        <View style={styles.sectionHeader}>
                            <Text style={styles.sectionTitle}>Jump Back In</Text>
                            <Text style={styles.sectionSubtitle}>
                                {recentPaintings.length} saved
                            </Text>
                        </View>

                        <ScrollView
                            horizontal
                            showsHorizontalScrollIndicator={false}
                            style={styles.horizontalScroll}
                            contentContainerStyle={{ paddingRight: SPACING.m }}
                        >
                            {recentPaintings.map((painting) => (
                                <JumpBackInCard
                                    key={painting.id}
                                    painting={painting}
                                    onPress={() => handleResumePainting(painting)}
                                    onDelete={() => handleDeletePainting(painting.id)}
                                />
                            ))}
                        </ScrollView>
                    </>
                )}

                <View style={{ height: 120 }} />
            </ScrollView>

            <DailyRewardModal
                visible={showDailyReward}
                onClose={() => setShowDailyReward(false)}
            />
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#F0F4F8',
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: SPACING.m,
        paddingVertical: SPACING.s,
    },
    avatarContainer: {
        width: 50,
        height: 50,
        borderRadius: 25,
        backgroundColor: 'white',
        ...SHADOWS.small,
        justifyContent: 'center',
        alignItems: 'center',
        overflow: 'hidden',
        borderWidth: 2,
        borderColor: 'white',
    },
    avatar: { width: '100%', height: '100%' },
    statsContainer: {
        flexDirection: 'row',
        gap: SPACING.s,
    },
    statPill: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: 'white',
        paddingHorizontal: 12,
        paddingVertical: 6,
        borderRadius: 20,
        gap: 4,
        elevation: 2,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.2,
        shadowRadius: 5,
    },
    coinIcon: { fontSize: 16 },
    statText: { ...FONTS.bold, color: '#2D3436', fontSize: 14 } as any,
    scrollContent: {
        padding: SPACING.m,
    },
    bannerContainer: {
        marginBottom: SPACING.xl,
        borderRadius: 30,
        position: 'relative',
        ...SHADOWS.medium,
        backgroundColor: 'white',
        overflow: 'hidden',
    },
    bannerFullImage: {
        width: '100%',
        height: '100%',
        position: 'absolute',
        top: 0,
        left: 0,
    },
    createButtonContainer: {
        position: 'absolute',
        bottom: 10,
        alignSelf: 'center',
        zIndex: 10,
    },
    sectionHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: SPACING.m,
    },
    sectionTitle: {
        ...FONTS.bold,
        fontSize: 22,
        color: '#2D3436',
        marginBottom: SPACING.m,
    } as any,
    sectionSubtitle: {
        fontSize: 14,
        color: '#64748B',
    },
    horizontalScroll: {
        marginBottom: SPACING.l,
        marginLeft: -SPACING.m,
        paddingLeft: SPACING.m,
    },
    artCard: {
        width: 160,
        backgroundColor: 'white',
        borderRadius: 20,
        marginRight: SPACING.m,
        padding: 10,
        elevation: 4,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
    },
    artCardImageContainer: {
        width: '100%',
        aspectRatio: 1,
        borderRadius: 14,
        overflow: 'hidden',
        backgroundColor: '#F1F5F9',
        marginBottom: 8,
    },
    artCardImage: {
        width: '100%',
        height: '100%',
    },
    artCardPlaceholder: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    progressBadge: {
        position: 'absolute',
        top: 8,
        right: 8,
        backgroundColor: 'rgba(0, 0, 0, 0.7)',
        paddingHorizontal: 8,
        paddingVertical: 4,
        borderRadius: 10,
    },
    progressBadgeText: {
        color: 'white',
        fontSize: 12,
        fontWeight: 'bold',
    },
    artCardTitle: {
        ...FONTS.medium,
        color: '#2D3436',
        marginBottom: 6,
        fontSize: 14,
    } as any,
    progressBarBg: {
        height: 6,
        backgroundColor: '#E2E8F0',
        borderRadius: 3,
        overflow: 'hidden',
        marginBottom: 8,
    },
    progressBarFill: {
        height: '100%',
        backgroundColor: '#10B981',
        borderRadius: 3,
    },
    continueButton: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#6366F1',
        paddingVertical: 8,
        borderRadius: 12,
        gap: 4,
    },
    continueText: {
        color: 'white',
        fontSize: 12,
        fontWeight: 'bold',
    },
});