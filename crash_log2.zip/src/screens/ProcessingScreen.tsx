import React, { useEffect, useState, useRef } from 'react';
import { View, Text, StyleSheet, Dimensions } from 'react-native';
import { COLORS, FONTS, SPACING } from '../theme';
import Animated, {
    useSharedValue,
    useAnimatedStyle,
    withRepeat,
    withTiming,
    withSequence,
    withSpring,
    Easing,
    interpolate,
    runOnJS,
} from 'react-native-reanimated';
import { processImage, generateImage, ProcessImageOptions } from '../services/api';
import { Canvas, Circle, Group, LinearGradient, vec } from '@shopify/react-native-skia';
import { AudioManager } from '../services/AudioManager';

const { width, height } = Dimensions.get('window');

const STEPS = [
    { text: 'Analyzing image...', emoji: '🔍', color: '#60A5FA' }, // Leaving colors for step dots, or we can unify them
    { text: 'Detecting edges...', emoji: '✏️', color: '#34D399' },
    { text: 'Extracting regions...', emoji: '🧩', color: '#FBBF24' },
    { text: 'Building color palette...', emoji: '🎨', color: '#F472B6' },
    { text: 'Generating paths...', emoji: '🛤️', color: '#A78BFA' },
    { text: 'Creating region map...', emoji: '🗺️', color: '#FB923C' },
    { text: 'Finalizing artwork...', emoji: '✨', color: '#22D3EE' },
];

// Floating Particle Component
const FloatingParticle = ({ delay, index }: { delay: number; index: number }) => {
    const translateY = useSharedValue(height);
    const translateX = useSharedValue(Math.random() * width);
    const opacity = useSharedValue(0);
    const scale = useSharedValue(0.5 + Math.random() * 0.5);

    useEffect(() => {
        const startAnimation = () => {
            translateY.value = height + 50;
            opacity.value = 0;

            translateY.value = withTiming(-100, {
                duration: 4000 + Math.random() * 2000,
                easing: Easing.linear,
            });

            opacity.value = withSequence(
                withTiming(0.8, { duration: 500 }),
                withTiming(0.8, { duration: 3000 }),
                withTiming(0, { duration: 500 })
            );
        };

        const timeout = setTimeout(startAnimation, delay);
        const interval = setInterval(startAnimation, 5000 + Math.random() * 2000);

        return () => {
            clearTimeout(timeout);
            clearInterval(interval);
        };
    }, []);

    const animatedStyle = useAnimatedStyle(() => ({
        transform: [
            { translateX: translateX.value },
            { translateY: translateY.value },
            { scale: scale.value },
        ],
        opacity: opacity.value,
    }));

    const colors = ['#FFD700', '#FF6B6B', '#4ECDC4', '#A78BFA', '#F472B6'];
    const color = colors[index % colors.length];

    return (
        <Animated.View style={[styles.particle, animatedStyle]}>
            <Text style={[styles.particleEmoji, { color }]}>✦</Text>
        </Animated.View>
    );
};

export const ProcessingScreen = ({ route, navigation }: any) => {
    const { imageUri, title, options, prompt, style } = route.params || {};
    const [step, setStep] = useState(0);
    const [error, setError] = useState<string | null>(null);
    const processingDone = useRef(false);

    // Animations
    const rotation = useSharedValue(0);
    const pulseScale = useSharedValue(1);
    const progressWidth = useSharedValue(0);
    const stepOpacity = useSharedValue(1);

    // Main rotation animation
    useEffect(() => {
        rotation.value = withRepeat(
            withTiming(360, { duration: 3000, easing: Easing.linear }),
            -1
        );

        pulseScale.value = withRepeat(
            withSequence(
                withTiming(1.1, { duration: 800, easing: Easing.inOut(Easing.ease) }),
                withTiming(1, { duration: 800, easing: Easing.inOut(Easing.ease) })
            ),
            -1
        );
    }, []);

    // Step progress animation
    useEffect(() => {
        const progress = ((step + 1) / STEPS.length) * 100;
        progressWidth.value = withSpring(progress, { damping: 15, stiffness: 100 });

        // Step transition animation
        stepOpacity.value = withSequence(
            withTiming(0, { duration: 150 }),
            withTiming(1, { duration: 300 })
        );
    }, [step]);

    // Step advancement
    useEffect(() => {
        let currentStep = 0;
        const stepInterval = setInterval(() => {
            if (currentStep < STEPS.length - 1 && !processingDone.current) {
                currentStep++;
                setStep(currentStep);
            }
        }, 1500);

        return () => clearInterval(stepInterval);
    }, []);

    // Backend processing
    useEffect(() => {
        const doProcess = async () => {
            try {
                if (!imageUri && !prompt) {
                    throw new Error('No image URI or prompt provided');
                }

                console.log('[Processing] Options:', options);
                let data;

                if (prompt) {
                    console.log('[Processing] Starting AI Generation with prompt:', prompt);
                    data = await generateImage(prompt, style || 'cartoon', options || {});
                } else {
                    console.log('[Processing] Starting with URI:', imageUri);
                    data = await processImage(
                        imageUri,
                        title || 'image.jpg',
                        'image/jpeg',
                        options || {}
                    );
                }

                processingDone.current = true;
                setStep(STEPS.length - 1);

                console.log('[Processing] Success! Regions:', data.regions?.length);

                // Play game music before navigating
                AudioManager.playGameMusic();

                setTimeout(() => {
                    navigation.replace('Game', { data, title });
                }, 800);
            } catch (err: any) {
                processingDone.current = true;
                console.error('[Processing] Error:', err);

                let msg = err?.response?.data?.detail || err?.message || 'Processing failed.';
                if (err?.code === 'ECONNABORTED') {
                    msg = 'Request timed out. Please check your connection.';
                }
                setError(msg);
            }
        };

        doProcess();
    }, []);

    const rotationStyle = useAnimatedStyle(() => ({
        transform: [{ rotate: `${rotation.value}deg` }],
    }));

    const pulseStyle = useAnimatedStyle(() => ({
        transform: [{ scale: pulseScale.value }],
    }));

    const progressStyle = useAnimatedStyle(() => ({
        width: `${progressWidth.value}%`,
    }));

    const stepStyle = useAnimatedStyle(() => ({
        opacity: stepOpacity.value,
    }));

    const currentStep = STEPS[step];

    return (
        <View style={styles.container}>
            {/* Background Particles */}
            {Array.from({ length: 15 }).map((_, i) => (
                <FloatingParticle key={i} delay={i * 300} index={i} />
            ))}

            {/* Main Content */}
            <View style={styles.content}>
                {/* Animated Icon */}
                <Animated.View style={[styles.iconContainer, pulseStyle]}>
                    <Animated.View style={rotationStyle}>
                        <View style={styles.iconRing}>
                            <Text style={styles.mainEmoji}>🖼️</Text>
                        </View>
                    </Animated.View>
                </Animated.View>

                {error ? (
                    <>
                        <Text style={styles.errorText}>❌ {error}</Text>
                        <Text
                            style={styles.retryBtn}
                            onPress={() => navigation.goBack()}
                        >
                            ← Go Back & Try Again
                        </Text>
                    </>
                ) : (
                    <>
                        {/* Current Step */}
                        <Animated.View style={[styles.stepContainer, stepStyle]}>
                            <Text style={[styles.stepEmoji]}>{currentStep.emoji}</Text>
                            <Text style={[styles.stepText]}>
                                {currentStep.text}
                            </Text>
                        </Animated.View>

                        {/* Title */}
                        <Text style={styles.titleText}>Processing "{title}"</Text>

                        {/* Progress Bar */}
                        <View style={styles.progressContainer}>
                            <View style={styles.progressBg}>
                                <Animated.View style={[styles.progressFill, progressStyle]} />
                            </View>
                            <Text style={styles.progressText}>
                                Step {step + 1} of {STEPS.length}
                            </Text>
                        </View>

                        {/* Step Indicators */}
                        <View style={styles.stepsIndicator}>
                            {STEPS.map((s, i) => (
                                <View
                                    key={i}
                                    style={[
                                        styles.stepDot,
                                        {
                                            backgroundColor: i <= step ? '#FF5C2E' : '#333',
                                            transform: [{ scale: i === step ? 1.3 : 1 }],
                                        },
                                    ]}
                                />
                            ))}
                        </View>
                    </>
                )}
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#1E1F22',
    },
    content: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: SPACING.xl,
    },
    particle: {
        position: 'absolute',
    },
    particleEmoji: {
        fontSize: 20,
    },
    iconContainer: {
        marginBottom: 40,
    },
    iconRing: {
        width: 120,
        height: 120,
        borderRadius: 60,
        backgroundColor: 'rgba(255, 92, 46, 0.1)',
        borderWidth: 3,
        borderColor: '#FF5C2E',
        justifyContent: 'center',
        alignItems: 'center',
        shadowColor: '#FF5C2E',
        shadowOffset: { width: 0, height: 0 },
        shadowOpacity: 0.5,
        shadowRadius: 20,
        elevation: 10,
    },
    mainEmoji: {
        fontSize: 50,
    },
    stepContainer: {
        alignItems: 'center',
        marginBottom: 8,
    },
    stepEmoji: {
        fontSize: 40,
        marginBottom: 16,
    },
    stepText: {
        fontFamily: 'PlusJakartaSans-Bold',
        fontWeight: '700',
        fontSize: 24,
        color: '#FAFAF8',
        textAlign: 'center',
    },
    titleText: {
        fontFamily: 'PlusJakartaSans-Regular',
        fontWeight: '400',
        fontSize: 14,
        color: '#8A8A8A',
        marginBottom: 32,
    },
    progressContainer: {
        width: '100%',
        marginBottom: 24,
    },
    progressBg: {
        height: 8,
        backgroundColor: '#2A2B2E',
        borderRadius: 4,
        overflow: 'hidden',
    },
    progressFill: {
        height: '100%',
        backgroundColor: '#FF5C2E',
        borderRadius: 4,
    },
    progressText: {
        fontFamily: 'PlusJakartaSans-Regular',
        color: '#8A8A8A',
        fontSize: 12,
        textAlign: 'center',
        marginTop: 8,
    },
    stepsIndicator: {
        flexDirection: 'row',
        gap: 8,
        marginBottom: 40,
    },
    stepDot: {
        width: 10,
        height: 10,
        borderRadius: 5,
    },
    errorText: {
        fontFamily: 'PlusJakartaSans-Bold',
        color: '#FF5C2E',
        fontSize: 18,
        textAlign: 'center',
        marginBottom: 20,
    },
    retryBtn: {
        fontFamily: 'PlusJakartaSans-Bold',
        color: '#FAFAF8',
        fontSize: 18,
        paddingVertical: 12,
        paddingHorizontal: 24,
    },
});