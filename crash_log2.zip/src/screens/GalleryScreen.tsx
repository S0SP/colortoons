import React, { useState, useCallback } from 'react';
import {
    View,
    Text,
    Image,
    TextInput,
    ScrollView,
    FlatList,
    TouchableOpacity,
    StyleSheet,
    Dimensions,
    Alert,
    Platform,
} from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import { AudioManager } from '../services/AudioManager';

const { width } = Dimensions.get('window');

// Assets - Use require with exact paths
// If images don't exist, create placeholder or use emoji fallback
const ASSETS: Record<string, any> = {};

try {
    ASSETS.tiger = require('../assets/gallery/card_1_tiger_1770252714051.png');
    ASSETS.castle = require('../assets/gallery/card_2_castle_1770252730046.png');
    ASSETS.mandala = require('../assets/gallery/card_3_mandala_1770252750695.png');
    ASSETS.car = require('../assets/gallery/card_4_car_1770252765697.png');
} catch (e) {
    console.warn('[Gallery] Some assets not found, using placeholders');
}

const CATEGORIES = [
    { id: 'all', label: 'All', bg: '#1F2937', text: '#FFFFFF' },
    { id: 'animals', label: 'Animals', bg: '#F97316', text: '#FFFFFF' },
    { id: 'nature', label: 'Nature', bg: '#22C55E', text: '#FFFFFF' },
    { id: 'fantasy', label: 'Fantasy', bg: '#A855F7', text: '#FFFFFF' },
    { id: 'vehicles', label: 'Vehicles', bg: '#3B82F6', text: '#FFFFFF' },
    { id: 'mandala', label: 'Mandala', bg: '#EC4899', text: '#FFFFFF' },
];

interface GalleryItem {
    id: string;
    title: string;
    image: any;
    emoji: string; // Fallback if image fails
    category: string;
    liked: boolean;
    isNew: boolean;
    difficulty: 'easy' | 'medium' | 'hard';
}

const INITIAL_CARDS: GalleryItem[] = [
    {
        id: '1',
        title: 'Jungle King',
        image: ASSETS.tiger,
        emoji: '🐯',
        category: 'animals',
        liked: false,
        isNew: false,
        difficulty: 'medium',
    },
    {
        id: '2',
        title: 'Fairytale Castle',
        image: ASSETS.castle,
        emoji: '🏰',
        category: 'fantasy',
        liked: false,
        isNew: true,
        difficulty: 'hard',
    },
    {
        id: '3',
        title: 'Zen Mandala',
        image: ASSETS.mandala,
        emoji: '🔮',
        category: 'mandala',
        liked: true,
        isNew: false,
        difficulty: 'hard',
    },
    {
        id: '4',
        title: 'Cyber Speed',
        image: ASSETS.car,
        emoji: '🚗',
        category: 'vehicles',
        liked: false,
        isNew: true,
        difficulty: 'medium',
    },
    {
        id: '5',
        title: 'Tiger Portrait',
        image: ASSETS.tiger,
        emoji: '🐅',
        category: 'animals',
        liked: false,
        isNew: false,
        difficulty: 'easy',
    },
    {
        id: '6',
        title: 'Magic Tower',
        image: ASSETS.castle,
        emoji: '🗼',
        category: 'fantasy',
        liked: false,
        isNew: true,
        difficulty: 'medium',
    },
    {
        id: '7',
        title: 'Forest Path',
        image: null,
        emoji: '🌲',
        category: 'nature',
        liked: false,
        isNew: false,
        difficulty: 'easy',
    },
    {
        id: '8',
        title: 'Ocean Waves',
        image: null,
        emoji: '🌊',
        category: 'nature',
        liked: true,
        isNew: false,
        difficulty: 'medium',
    },
];

const DifficultyBadge = ({ difficulty }: { difficulty: string }) => {
    const colors = {
        easy: { bg: '#D1FAE5', text: '#059669' },
        medium: { bg: '#FEF3C7', text: '#D97706' },
        hard: { bg: '#FEE2E2', text: '#DC2626' },
    };
    const color = colors[difficulty as keyof typeof colors] || colors.medium;

    return (
        <View style={[styles.difficultyBadge, { backgroundColor: color.bg }]}>
            <Text style={[styles.difficultyText, { color: color.text }]}>
                {difficulty.charAt(0).toUpperCase() + difficulty.slice(1)}
            </Text>
        </View>
    );
};

const GalleryCard = ({
    item,
    onPress,
    onLike,
}: {
    item: GalleryItem;
    onPress: () => void;
    onLike: () => void;
}) => {
    const [imageError, setImageError] = useState(false);

    return (
        <TouchableOpacity
            style={styles.cardContainer}
            onPress={onPress}
            activeOpacity={0.9}
        >
            <View style={styles.imageWrapper}>
                {item.image && !imageError ? (
                    <Image
                        source={item.image}
                        style={styles.cardImage}
                        onError={() => setImageError(true)}
                    />
                ) : (
                    <View style={styles.emojiPlaceholder}>
                        <Text style={styles.emojiText}>{item.emoji}</Text>
                    </View>
                )}

                {/* New Badge */}
                {item.isNew && (
                    <View style={styles.newBadge}>
                        <Text style={styles.newBadgeText}>NEW</Text>
                    </View>
                )}

                {/* Difficulty Badge */}
                <View style={styles.difficultyContainer}>
                    <DifficultyBadge difficulty={item.difficulty} />
                </View>
            </View>

            <View style={styles.cardFooter}>
                <Text style={styles.cardTitle} numberOfLines={1}>
                    {item.title}
                </Text>
                <TouchableOpacity onPress={onLike} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
                    <Icon
                        name={item.liked ? 'heart' : 'heart-outline'}
                        size={22}
                        color={item.liked ? '#EF4444' : '#9CA3AF'}
                    />
                </TouchableOpacity>
            </View>
        </TouchableOpacity>
    );
};

export const GalleryScreen = ({ navigation }: any) => {
    const [searchQuery, setSearchQuery] = useState('');
    const [selectedCategory, setSelectedCategory] = useState('all');
    const [cards, setCards] = useState<GalleryItem[]>(INITIAL_CARDS);

    // Play app music when focused
    useFocusEffect(
        useCallback(() => {
            AudioManager.playAppMusic();
            return () => { };
        }, [])
    );

    // Filter Logic
    const filteredCards = cards.filter((card) => {
        const matchesCategory =
            selectedCategory === 'all' || card.category === selectedCategory;
        const matchesSearch = card.title
            .toLowerCase()
            .includes(searchQuery.toLowerCase());
        return matchesCategory && matchesSearch;
    });

    // Handlers
    const handleLike = (id: string) => {
        setCards((currentCards) =>
            currentCards.map((card) =>
                card.id === id ? { ...card, liked: !card.liked } : card
            )
        );
    };

    const handleCardPress = (item: GalleryItem) => {
        console.log('[Gallery] Opening:', item.title);

        // Get the actual image URI for processing
        let imageUri: string | null = null;

        if (item.image) {
            // For require() images, resolve the asset source
            const resolved = Image.resolveAssetSource(item.image);
            imageUri = resolved?.uri;
        }

        if (!imageUri) {
            Alert.alert(
                'Image Not Available',
                'This image is not available for processing. Please try uploading your own image.',
                [{ text: 'OK' }]
            );
            return;
        }

        // Navigate to Processing Screen with the image
        navigation.navigate('Processing', {
            imageUri: imageUri,
            title: item.title,
            id: item.id,
            options: {
                numColors: item.difficulty === 'easy' ? 16 : item.difficulty === 'medium' ? 32 : 64,
                targetRegions: item.difficulty === 'easy' ? 150 : item.difficulty === 'medium' ? 400 : 800,
                minRegionArea: item.difficulty === 'easy' ? 80 : item.difficulty === 'medium' ? 40 : 20,
            },
        });
    };

    return (
        <SafeAreaView style={styles.screen} edges={['top']}>
            <View style={styles.headerContainer}>
                {/* Title */}
                <Text style={styles.headerTitle}>Gallery</Text>

                {/* Search Bar */}
                <View style={styles.searchBar}>
                    <Icon
                        name="search-outline"
                        size={20}
                        color="#9CA3AF"
                        style={{ marginRight: 10 }}
                    />
                    <TextInput
                        style={styles.searchInput}
                        placeholder="Search paintings..."
                        placeholderTextColor="#9CA3AF"
                        value={searchQuery}
                        onChangeText={setSearchQuery}
                    />
                    {searchQuery.length > 0 && (
                        <TouchableOpacity onPress={() => setSearchQuery('')}>
                            <Icon name="close-circle" size={20} color="#9CA3AF" />
                        </TouchableOpacity>
                    )}
                </View>

                {/* Categories */}
                <ScrollView
                    horizontal
                    showsHorizontalScrollIndicator={false}
                    contentContainerStyle={styles.categoryList}
                >
                    {CATEGORIES.map((cat) => {
                        const isActive = selectedCategory === cat.id;
                        return (
                            <TouchableOpacity
                                key={cat.id}
                                style={[
                                    styles.categoryPill,
                                    { backgroundColor: isActive ? cat.bg : '#E5E7EB' },
                                ]}
                                onPress={() => setSelectedCategory(cat.id)}
                            >
                                <Text
                                    style={[
                                        styles.categoryText,
                                        { color: isActive ? cat.text : '#4B5563' },
                                    ]}
                                >
                                    {cat.label}
                                </Text>
                            </TouchableOpacity>
                        );
                    })}
                </ScrollView>
            </View>

            <FlatList
                data={filteredCards}
                renderItem={({ item }) => (
                    <GalleryCard
                        item={item}
                        onPress={() => handleCardPress(item)}
                        onLike={() => handleLike(item.id)}
                    />
                )}
                keyExtractor={(item) => item.id}
                numColumns={2}
                columnWrapperStyle={styles.columnWrapper}
                contentContainerStyle={styles.gridContainer}
                showsVerticalScrollIndicator={false}
                ListEmptyComponent={
                    <View style={styles.emptyState}>
                        <Text style={styles.emptyEmoji}>🔍</Text>
                        <Text style={styles.emptyText}>No paintings found</Text>
                        <Text style={styles.emptySubtext}>
                            Try a different search or category
                        </Text>
                    </View>
                }
            />
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    screen: {
        flex: 1,
        backgroundColor: '#F8FAFC',
    },
    headerContainer: {
        paddingHorizontal: 16,
        paddingTop: 10,
        paddingBottom: 16,
        backgroundColor: '#FFFFFF',
        borderBottomWidth: 1,
        borderBottomColor: '#E5E7EB',
    },
    headerTitle: {
        fontSize: 28,
        fontWeight: 'bold',
        color: '#1F2937',
        marginBottom: 16,
    },
    searchBar: {
        backgroundColor: '#F3F4F6',
        borderRadius: 12,
        height: 48,
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 16,
        marginBottom: 16,
    },
    searchInput: {
        flex: 1,
        fontSize: 16,
        color: '#1F2937',
    },
    categoryList: {
        paddingRight: 16,
        gap: 8,
    },
    categoryPill: {
        paddingVertical: 10,
        paddingHorizontal: 20,
        borderRadius: 20,
        marginRight: 8,
    },
    categoryText: {
        fontWeight: '600',
        fontSize: 14,
    },
    gridContainer: {
        paddingHorizontal: 12,
        paddingTop: 16,
        paddingBottom: 100,
    },
    columnWrapper: {
        justifyContent: 'space-between',
        paddingHorizontal: 4,
    },
    cardContainer: {
        backgroundColor: '#FFFFFF',
        borderRadius: 16,
        padding: 8,
        width: (width - 40) / 2,
        marginBottom: 16,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.08,
        shadowRadius: 8,
        elevation: 4,
    },
    imageWrapper: {
        position: 'relative',
        width: '100%',
        aspectRatio: 1,
        borderRadius: 12,
        overflow: 'hidden',
        backgroundColor: '#F3F4F6',
    },
    cardImage: {
        width: '100%',
        height: '100%',
        resizeMode: 'cover',
    },
    emojiPlaceholder: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#EEF2FF',
    },
    emojiText: {
        fontSize: 50,
    },
    cardFooter: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginTop: 10,
        paddingHorizontal: 4,
    },
    cardTitle: {
        fontWeight: '600',
        fontSize: 14,
        color: '#1F2937',
        flex: 1,
        marginRight: 8,
    },
    newBadge: {
        position: 'absolute',
        top: 8,
        left: 8,
        backgroundColor: '#EF4444',
        paddingHorizontal: 8,
        paddingVertical: 4,
        borderRadius: 8,
    },
    newBadgeText: {
        color: '#FFFFFF',
        fontSize: 10,
        fontWeight: 'bold',
    },
    difficultyContainer: {
        position: 'absolute',
        bottom: 8,
        right: 8,
    },
    difficultyBadge: {
        paddingHorizontal: 8,
        paddingVertical: 4,
        borderRadius: 8,
    },
    difficultyText: {
        fontSize: 10,
        fontWeight: '600',
    },
    emptyState: {
        alignItems: 'center',
        paddingVertical: 60,
    },
    emptyEmoji: {
        fontSize: 60,
        marginBottom: 16,
    },
    emptyText: {
        fontSize: 18,
        fontWeight: '600',
        color: '#4B5563',
        marginBottom: 8,
    },
    emptySubtext: {
        fontSize: 14,
        color: '#9CA3AF',
    },
});