import React, { useState, useEffect } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TextInput,
    ScrollView,
    TouchableOpacity,
    ActivityIndicator,
    Alert,
    Image,
    Platform,
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { COLORS, SPACING, FONTS, SHADOWS } from '../theme';
import { StyleCard } from '../components/StyleCard';
import { DifficultySlider } from '../components/DifficultySlider';
import { RegionSlider, getRegionLabel } from '../components/RegionSlider';
import { useUserStore } from '../store';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { AudioManager } from '../services/AudioManager';

import Voice, { SpeechResultsEvent, SpeechErrorEvent } from '@react-native-voice/voice';
import { launchImageLibrary, launchCamera } from 'react-native-image-picker';
import { ProcessImageOptions } from '../services/api';

const STYLES = [
    { id: 'cartoon', label: 'Cartoon', emoji: '🎨' },
    { id: 'realistic', label: 'Realistic', emoji: '👁️' },
    { id: 'pixel', label: 'Pixel', emoji: '👾' },
    { id: 'anime', label: 'Anime', emoji: '🎌' },
];

export const CreationScreen = () => {
    const navigation = useNavigation();
    const [prompt, setPrompt] = useState('');
    const [selectedStyle, setSelectedStyle] = useState('cartoon');
    const [difficulty, setDifficulty] = useState(50);
    const [targetRegions, setTargetRegions] = useState(400);
    const [loading, setLoading] = useState(false);
    const [isListening, setIsListening] = useState(false);
    const [selectedImageUri, setSelectedImageUri] = useState<string | null>(null);
    const [selectedImageTitle, setSelectedImageTitle] = useState<string | null>(null);

    const { coins, useEnergy } = useUserStore();

    // Play app music when screen is focused and reset state
    useFocusEffect(
        React.useCallback(() => {
            AudioManager.playAppMusic();
            setPrompt('');
            setSelectedImageUri(null);
            setSelectedImageTitle(null);
            return () => { };
        }, [])
    );

    // Get API options based on sliders
    const getProcessingOptions = (): ProcessImageOptions => {
        // Difficulty affects numColors and minRegionArea
        let numColors: number;
        let minRegionArea: number;

        if (difficulty < 25) {
            numColors = 12;
            minRegionArea = 100;
        } else if (difficulty < 50) {
            numColors = 24;
            minRegionArea = 50;
        } else if (difficulty < 75) {
            numColors = 32;
            minRegionArea = 25;
        } else if (difficulty < 90) {
            numColors = 64;
            minRegionArea = 10;
        } else {
            numColors = 128;
            minRegionArea = 1;
        }

        return {
            numColors,
            minRegionArea,
            targetRegions, // Direct from slider
            maxDimension: 1024,
        };
    };

    // Voice recognition setup
    useEffect(() => {
        const onSpeechStart = () => setIsListening(true);
        const onSpeechEnd = () => setIsListening(false);
        const onSpeechError = (e: SpeechErrorEvent) => {
            console.error('[Voice] Error:', e);
            setIsListening(false);
            if (e.error?.message) {
                Alert.alert('Voice Error', e.error.message);
            }
        };
        const onSpeechResults = (e: SpeechResultsEvent) => {
            if (e.value && e.value[0]) {
                setPrompt((prev) => (prev ? `${prev} ${e.value![0]}` : e.value![0]));
            }
        };

        Voice.onSpeechStart = onSpeechStart;
        Voice.onSpeechEnd = onSpeechEnd;
        Voice.onSpeechError = onSpeechError;
        Voice.onSpeechResults = onSpeechResults;

        return () => {
            try {
                Voice.destroy()
                    .then(() => Voice.removeAllListeners())
                    .catch((err) => console.warn('[Voice] Teardown error:', err));
            } catch (e) {
                console.warn('[Voice] Teardown error:', e);
            }
        };
    }, []);

    const toggleListening = async () => {
        try {
            if (isListening) {
                try {
                    await Voice.stop();
                } catch (e) {
                    console.warn('[Voice] Stop error:', e);
                }
                setIsListening(false);
            } else {
                // Request microphone permission on Android
                if (Platform.OS === 'android') {
                    const { PermissionsAndroid } = require('react-native');
                    const granted = await PermissionsAndroid.request(
                        PermissionsAndroid.PERMISSIONS.RECORD_AUDIO,
                        {
                            title: 'Microphone Permission',
                            message: 'ColorArt needs microphone access for voice input',
                            buttonPositive: 'Allow',
                        }
                    );
                    if (granted !== PermissionsAndroid.RESULTS.GRANTED) {
                        Alert.alert('Permission Denied', 'Microphone permission is required for voice input');
                        return;
                    }
                }
                try {
                    await Voice.start('en-US');
                } catch (e: any) {
                    console.error('[Voice] Start error:', e);
                    setIsListening(false);
                    Alert.alert('Voice Not Available', 'Voice recognition might not be supported on this device/emulator.');
                }
            }
        } catch (e: any) {
            console.error('[Voice] Toggle error:', e);
            setIsListening(false);
            Alert.alert('Voice Error', e.message || 'Failed to start voice recognition');
        }
    };

    const handleCreate = async () => {
        if (!prompt.trim()) {
            Alert.alert('Enter a Prompt', 'Please describe what you want to paint!');
            return;
        }

        const options = getProcessingOptions();
        console.log('[Creation] Generate AI options:', options);

        navigation.navigate('Processing' as any, {
            prompt: prompt.trim(),
            style: selectedStyle,
            title: `AI: ${prompt.trim().substring(0, 20)}...`,
            options,
        });
    };

    const handleProcessImage = () => {
        if (!selectedImageUri) return;
        const options = getProcessingOptions();
        console.log('[Creation] Processing options:', options);

        navigation.navigate('Processing' as any, {
            imageUri: selectedImageUri,
            title: selectedImageTitle ?? 'My Painting',
            options,
        });
    };

    const handleImageUpload = async () => {
        try {
            const result = await launchImageLibrary({
                mediaType: 'photo',
                quality: 0.9,
                maxWidth: 2048,
                maxHeight: 2048,
            });

            if (result.didCancel || !result.assets?.[0]) return;
            if (result.errorMessage) {
                Alert.alert('Error', result.errorMessage);
                return;
            }

            const asset = result.assets[0];
            if (asset?.uri) {
                setSelectedImageUri(asset.uri);
                setSelectedImageTitle(asset.fileName ?? 'My Painting');
            }
        } catch (err: any) {
            console.error('[Creation] Image pick error:', err);
            Alert.alert('Error', err.message || 'Failed to pick image');
        }
    };

    const handleMainAction = () => {
        if (prompt.trim()) {
            handleCreate();
        } else if (selectedImageUri) {
            handleProcessImage();
        } else {
            Alert.alert('Missing Input', 'Please enter a prompt or select an image!');
        }
    };

    const regionInfo = getRegionLabel(targetRegions);

    return (
        <SafeAreaView style={styles.container}>
            <ScrollView showsVerticalScrollIndicator={false}>
                {/* Header: Fox & Bubble & Input */}
                <View style={styles.topSection}>
                    <Image
                        source={require('../assets/fox_peeking.png')}
                        style={styles.foxPeeking as any}
                        resizeMode="contain"
                    />

                    <View style={styles.speechBubbleContainer}>
                        <View style={styles.speechBubble}>
                            <Text style={styles.speechText}>What shall we{'\n'}paint today?</Text>
                            <View style={styles.bubbleTail} />
                        </View>
                    </View>

                    <View style={[styles.inputCard, selectedImageUri ? { height: 260 } : {}]}>
                        {selectedImageUri && (
                            <View style={[styles.selectedImageContainer, { flex: 0, height: 75, marginBottom: 10 }]}>
                                <Image source={{ uri: selectedImageUri }} style={styles.selectedImagePreview as any} borderRadius={16} />
                                <TouchableOpacity
                                    style={styles.clearImageBtn}
                                    onPress={() => {
                                        setSelectedImageUri(null);
                                        setSelectedImageTitle(null);
                                    }}
                                >
                                    <Icon name="close-circle" size={28} color="#FFF" />
                                </TouchableOpacity>
                            </View>
                        )}

                        <View style={styles.inputInnerContainer}>
                            <TextInput
                                style={styles.input as any}
                                placeholder={selectedImageUri ? "Add a prompt for AI styling (optional)..." : "Describe your dream painting..."}
                                placeholderTextColor="#94A3B8"
                                multiline
                                value={prompt}
                                onChangeText={setPrompt}
                            />
                        </View>

                        {/* Mic Button */}
                        <TouchableOpacity
                            style={[styles.micButton, isListening && styles.micButtonActive]}
                            onPress={toggleListening}
                        >
                            <Icon
                                name={isListening ? 'microphone-off' : 'microphone'}
                                size={28}
                                color={isListening ? '#FFF' : '#00A3FF'}
                            />
                            {isListening && (
                                <View style={styles.listeningPulse} />
                            )}
                        </TouchableOpacity>

                        {/* Image Upload Button */}
                        <TouchableOpacity
                            style={styles.uploadButton}
                            onPress={handleImageUpload}
                            disabled={loading}
                        >
                            <Icon name="image-plus" size={28} color="#7d51c1" />
                        </TouchableOpacity>
                    </View>
                </View>

                {/* Style Selector */}
                {!selectedImageUri && prompt.trim().length > 0 && (
                    <>
                        <Text style={styles.sectionTitle as any}>Pick a Style</Text>
                        <ScrollView
                            horizontal
                            showsHorizontalScrollIndicator={false}
                            style={styles.styleList}
                        >
                            {STYLES.map((s) => (
                                <StyleCard
                                    key={s.id}
                                    label={s.label}
                                    emoji={s.emoji}
                                    selected={selectedStyle === s.id}
                                    onPress={() => setSelectedStyle(s.id)}
                                />
                            ))}
                        </ScrollView>
                    </>
                )}

                {/* Difficulty Slider */}
                <Text style={styles.sectionTitle as any}>Difficulty</Text>
                <View style={[styles.sliderContainer, { marginBottom: 6 }]}>
                    <DifficultySlider
                        value={difficulty}
                        onValueChange={setDifficulty}
                        min={0}
                        max={100}
                    />
                </View>

                {/* Region Count Slider - NEW */}
                <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 12 }}>
                    <Text style={[styles.sectionTitle as any, { marginTop: 0, marginBottom: 0 }]}>Detail Level</Text>
                    <Text style={{ fontSize: 20, marginLeft: 10, marginTop: -2 }}>{regionInfo.emoji}</Text>
                    <Text style={{ fontSize: 16, fontWeight: '900', letterSpacing: 1, color: regionInfo.color, marginLeft: 4, marginTop: -2 }}>{regionInfo.label}</Text>
                </View>
                <View style={[styles.sliderContainer, { marginBottom: 0 }]}>
                    <RegionSlider
                        value={targetRegions}
                        onValueChange={setTargetRegions}
                        min={20}
                        max={4000}
                    />
                </View>

                {/* Create Button */}
                <TouchableOpacity
                    style={[styles.button, ((!selectedImageUri && !prompt.trim()) || loading) && styles.disabledButton]}
                    onPress={handleMainAction}
                    disabled={loading || (!selectedImageUri && !prompt.trim())}
                >
                    {loading ? (
                        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                            <ActivityIndicator color="#FFF" />
                            <Text style={[styles.buttonText, { marginLeft: 10 }]}>
                                Processing...
                            </Text>
                        </View>
                    ) : (
                        <Text style={styles.buttonText}>✨ GENERATE WITH AI</Text>
                    )}
                </TouchableOpacity>

                <View style={{ height: 120 }} />
            </ScrollView>
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#e9dafe',
        padding: SPACING.m,
    },
    topSection: {
        marginTop: 108,
        marginBottom: SPACING.l,
        position: 'relative',
        height: 200,
    },
    speechBubbleContainer: {
        position: 'absolute',
        top: -50,
        right: 20,
        left: 150,
        zIndex: 5,
        alignItems: 'flex-start',
    },
    speechBubble: {
        backgroundColor: 'white',
        paddingHorizontal: 20,
        paddingVertical: 14,
        borderRadius: 24,
        ...SHADOWS.small,
        elevation: 4,
        width: '100%',
    },
    speechText: {
        fontWeight: '700' as const,
        color: '#7d51c1',
        fontSize: 20,
        lineHeight: 24,
        textAlign: 'center',
    },
    bubbleTail: {
        position: 'absolute',
        left: -12,
        top: '50%',
        marginTop: 10,
        width: 0,
        height: 0,
        backgroundColor: 'transparent',
        borderStyle: 'solid',
        borderTopWidth: 10,
        borderBottomWidth: 10,
        borderRightWidth: 15,
        borderTopColor: 'transparent',
        borderBottomColor: 'transparent',
        borderRightColor: 'white',
    },
    foxPeeking: {
        position: 'absolute',
        bottom: 181.5,
        left: 20,
        width: 140,
        height: 140,
        zIndex: 2,
    },
    inputCard: {
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0,
        backgroundColor: '#FFFFFF',
        borderRadius: 34,
        padding: 6,
        height: 198,
        elevation: 8,
        shadowColor: '#6D28D9',
        shadowOffset: { width: 0, height: 6 },
        shadowOpacity: 0.2,
        shadowRadius: 10,
        zIndex: 1,
    },
    inputInnerContainer: {
        flex: 1,
        backgroundColor: '#F8FAFC',
        borderRadius: 28,
        borderWidth: 2,
        borderColor: '#E2E8F0',
        padding: SPACING.m,
        paddingTop: 34,
        paddingRight: 80,
    },
    input: {
        ...FONTS.medium,
        fontSize: 20,
        color: '#475569',
        flex: 1,
        textAlignVertical: 'top',
        marginTop: -10,
    },
    selectedImageContainer: {
        flex: 1,
        position: 'relative',
        borderRadius: 28,
        overflow: 'hidden',
    },
    selectedImagePreview: {
        width: '100%',
        height: '100%',
        backgroundColor: '#F8FAFC',
        borderRadius: 24,
    },
    clearImageBtn: {
        position: 'absolute',
        top: 10,
        right: 10,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.5,
        shadowRadius: 4,
        elevation: 5,
    },
    micButton: {
        position: 'absolute',
        bottom: 30,
        right: 16,
        width: 56,
        height: 56,
        borderRadius: 28,
        backgroundColor: '#FFF',
        borderWidth: 3,
        borderColor: '#00A3FF',
        justifyContent: 'center',
        alignItems: 'center',
        elevation: 2,
    },
    micButtonActive: {
        backgroundColor: '#EF4444',
        borderColor: '#EF4444',
    },
    listeningPulse: {
        position: 'absolute',
        width: 70,
        height: 70,
        borderRadius: 35,
        backgroundColor: 'rgba(239, 68, 68, 0.3)',
    },
    uploadButton: {
        position: 'absolute',
        bottom: 30,
        left: 16,
        width: 56,
        height: 56,
        borderRadius: 28,
        backgroundColor: '#FFF',
        borderWidth: 3,
        borderColor: '#7d51c1',
        justifyContent: 'center',
        alignItems: 'center',
        elevation: 2,
    },
    sectionTitle: {
        ...FONTS.bold,
        fontSize: 20,
        color: 'rgba(51, 13, 107, 1)',
        marginBottom: 14,
        marginTop: 0,
        marginLeft: SPACING.m,
    },
    styleList: {
        marginBottom: SPACING.l,
        overflow: 'visible',
        maxHeight: 140,
    },
    sliderContainer: {
        paddingHorizontal: SPACING.m,
        marginBottom: SPACING.m,
    },
    button: {
        backgroundColor: '#7d51c1',
        padding: SPACING.m,
        borderRadius: 30,
        alignItems: 'center',
        shadowColor: '#7d51c1',
        shadowOpacity: 0.5,
        shadowRadius: 10,
        elevation: 8,
        marginTop: 12,
    },
    disabledButton: {
        opacity: 0.5,
    },
    buttonText: {
        color: COLORS.white,
        fontWeight: 'bold' as const,
        fontSize: 20,
    },
    divider: {
        flexDirection: 'row',
        alignItems: 'center',
        marginVertical: SPACING.l,
    },
    dividerLine: {
        flex: 1,
        height: 1,
        backgroundColor: '#D1D5DB',
    },
    dividerText: {
        marginHorizontal: SPACING.m,
        color: '#6B7280',
        fontSize: 14,
    },
    uploadMainButton: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#FFF',
        padding: SPACING.m,
        borderRadius: 30,
        borderWidth: 2,
        borderColor: '#7d51c1',
        gap: 10,
    },
    uploadMainButtonText: {
        color: '#7d51c1',
        fontWeight: 'bold' as const,
        fontSize: 18,
    },
});