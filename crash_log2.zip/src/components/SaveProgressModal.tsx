/**
 * Save Progress Modal
 * ===================
 * Beautiful modal that appears when user tries to exit game
 */

import React from 'react';
import {
    View,
    Text,
    StyleSheet,
    Modal,
    TouchableOpacity,
    Dimensions,
} from 'react-native';
import Animated, {
    useSharedValue,
    useAnimatedStyle,
    withSpring,
    withSequence,
    withTiming,
    runOnJS,
} from 'react-native-reanimated';
import { BlurView } from '@react-native-community/blur';

const { width } = Dimensions.get('window');

interface SaveProgressModalProps {
    visible: boolean;
    progress: number; // 0-100
    onSave: () => void;
    onDiscard: () => void;
    onCancel: () => void;
}

export const SaveProgressModal: React.FC<SaveProgressModalProps> = ({
    visible,
    progress,
    onSave,
    onDiscard,
    onCancel,
}) => {
    const scale = useSharedValue(0.8);
    const opacity = useSharedValue(0);

    React.useEffect(() => {
        if (visible) {
            scale.value = withSpring(1, { damping: 12, stiffness: 150 });
            opacity.value = withTiming(1, { duration: 200 });
        } else {
            scale.value = withTiming(0.8, { duration: 150 });
            opacity.value = withTiming(0, { duration: 150 });
        }
    }, [visible]);

    const containerStyle = useAnimatedStyle(() => ({
        transform: [{ scale: scale.value }],
        opacity: opacity.value,
    }));

    const backdropStyle = useAnimatedStyle(() => ({
        opacity: opacity.value,
    }));

    if (!visible) return null;

    return (
        <Modal transparent visible={visible} animationType="none">
            <View style={styles.overlay}>
                <Animated.View style={[styles.backdrop, backdropStyle]}>
                    <TouchableOpacity
                        style={StyleSheet.absoluteFill}
                        onPress={onCancel}
                        activeOpacity={1}
                    />
                </Animated.View>

                <Animated.View style={[styles.modal, containerStyle]}>
                    {/* Icon */}
                    <View style={styles.iconContainer}>
                        <Text style={styles.icon}>🎨</Text>
                    </View>

                    {/* Title */}
                    <Text style={styles.title}>Save Your Progress?</Text>

                    {/* Progress Display */}
                    <View style={styles.progressContainer}>
                        <View style={styles.progressBar}>
                            <View
                                style={[styles.progressFill, { width: `${progress}%` }]}
                            />
                        </View>
                        <Text style={styles.progressText}>{progress}% Complete</Text>
                    </View>

                    {/* Message */}
                    <Text style={styles.message}>
                        You've made great progress! Save now to continue later from your Home screen.
                    </Text>

                    {/* Buttons */}
                    <View style={styles.buttons}>
                        <TouchableOpacity
                            style={styles.saveButton}
                            onPress={onSave}
                            activeOpacity={0.8}
                        >
                            <Text style={styles.saveButtonText}>Save & Exit</Text>
                        </TouchableOpacity>

                        <TouchableOpacity
                            style={styles.discardButton}
                            onPress={onDiscard}
                            activeOpacity={0.8}
                        >
                            <Text style={styles.discardButtonText}>Discard</Text>
                        </TouchableOpacity>

                        <TouchableOpacity
                            style={styles.cancelButton}
                            onPress={onCancel}
                            activeOpacity={0.8}
                        >
                            <Text style={styles.cancelButtonText}>Continue Painting</Text>
                        </TouchableOpacity>
                    </View>
                </Animated.View>
            </View>
        </Modal>
    );
};

const styles = StyleSheet.create({
    overlay: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    backdrop: {
        ...StyleSheet.absoluteFillObject,
        backgroundColor: 'rgba(0, 0, 0, 0.6)',
    },
    modal: {
        width: width - 48,
        backgroundColor: 'white',
        borderRadius: 24,
        padding: 24,
        alignItems: 'center',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 10 },
        shadowOpacity: 0.3,
        shadowRadius: 20,
        elevation: 20,
    },
    iconContainer: {
        width: 80,
        height: 80,
        borderRadius: 40,
        backgroundColor: '#F0F9FF',
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 16,
    },
    icon: {
        fontSize: 40,
    },
    title: {
        fontSize: 22,
        fontWeight: 'bold',
        color: '#1E293B',
        marginBottom: 16,
    },
    progressContainer: {
        width: '100%',
        marginBottom: 16,
    },
    progressBar: {
        height: 12,
        backgroundColor: '#E2E8F0',
        borderRadius: 6,
        overflow: 'hidden',
    },
    progressFill: {
        height: '100%',
        backgroundColor: '#10B981',
        borderRadius: 6,
    },
    progressText: {
        fontSize: 14,
        color: '#10B981',
        fontWeight: '600',
        textAlign: 'center',
        marginTop: 8,
    },
    message: {
        fontSize: 14,
        color: '#64748B',
        textAlign: 'center',
        lineHeight: 20,
        marginBottom: 24,
    },
    buttons: {
        width: '100%',
        gap: 12,
    },
    saveButton: {
        backgroundColor: '#10B981',
        paddingVertical: 16,
        borderRadius: 16,
        alignItems: 'center',
    },
    saveButtonText: {
        color: 'white',
        fontSize: 18,
        fontWeight: 'bold',
    },
    discardButton: {
        backgroundColor: '#FEE2E2',
        paddingVertical: 14,
        borderRadius: 16,
        alignItems: 'center',
    },
    discardButtonText: {
        color: '#EF4444',
        fontSize: 16,
        fontWeight: '600',
    },
    cancelButton: {
        paddingVertical: 12,
        alignItems: 'center',
    },
    cancelButtonText: {
        color: '#64748B',
        fontSize: 14,
        fontWeight: '500',
    },
});