import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Dimensions, Platform } from 'react-native';
import { BlurView } from '@react-native-community/blur';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { BottomTabBarProps } from '@react-navigation/bottom-tabs';
import { useUserStore } from '../store/useUserStore';

const { width } = Dimensions.get('window');

export const CustomTabBar = ({ state, descriptors, navigation }: BottomTabBarProps) => {
    // Get daily reward status for badge
    const canClaimDailyReward = useUserStore((s) => s.canClaimDailyReward());

    return (
        <View style={styles.dockWrapper}>
            {/* Blur Background */}
            <BlurView
                style={styles.dockBlur}
                blurType="light"
                blurAmount={20}
                reducedTransparencyFallbackColor="white"
            />

            <View style={styles.dockContent}>
                {state.routes.map((route, index) => {
                    const { options } = descriptors[route.key];
                    const label =
                        options.tabBarLabel !== undefined
                            ? options.tabBarLabel
                            : options.title !== undefined
                                ? options.title
                                : route.name;

                    const isFocused = state.index === index;

                    const onPress = () => {
                        const event = navigation.emit({
                            type: 'tabPress',
                            target: route.key,
                            canPreventDefault: true,
                        });

                        if (!isFocused && !event.defaultPrevented) {
                            navigation.navigate(route.name);
                        }
                    };

                    // Define icons based on route name
                    let iconName = 'alert-circle';
                    if (route.name === 'Home') iconName = isFocused ? 'home' : 'home-outline';
                    else if (route.name === 'Gallery') iconName = isFocused ? 'image-multiple' : 'image-multiple-outline';
                    else if (route.name === 'Magic') iconName = isFocused ? 'auto-fix' : 'auto-fix';
                    else if (route.name === 'Profile') iconName = isFocused ? 'account' : 'account-outline';

                    // Show badge on Home if daily reward available
                    const showBadge = route.name === 'Home' && canClaimDailyReward;

                    // Render Active Tab with Gradient
                    if (isFocused) {
                        return (
                            <TouchableOpacity
                                key={index}
                                onPress={onPress}
                                style={styles.dockItem}
                                activeOpacity={0.8}
                            >
                                <LinearGradient
                                    colors={['#A855F7', '#6366F1']}
                                    start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
                                    style={styles.activeTabBackground}
                                >
                                    <Icon name={iconName} size={24} color="#FFFFFF" />
                                </LinearGradient>
                                {showBadge && <View style={styles.badge} />}
                            </TouchableOpacity>
                        );
                    }

                    // Render Inactive Tab
                    return (
                        <TouchableOpacity
                            key={index}
                            onPress={onPress}
                            style={styles.dockItem}
                            activeOpacity={0.8}
                        >
                            <View style={styles.inactiveIconContainer}>
                                <Icon name={iconName} size={24} color="#64748B" />
                                {showBadge && <View style={styles.badge} />}
                            </View>
                        </TouchableOpacity>
                    );
                })}
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    dockWrapper: {
        position: 'absolute',
        bottom: 30,
        width: '90%',
        alignSelf: 'center',
        height: 75,
        borderRadius: 40,
        overflow: 'hidden',
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 10 },
        shadowOpacity: 0.15,
        shadowRadius: 20,
        elevation: 10,
        backgroundColor: 'rgba(255,255,255,0.7)',
    },
    dockBlur: {
        ...StyleSheet.absoluteFillObject,
    },
    dockContent: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-around',
        alignItems: 'center',
        paddingHorizontal: 10,
    },
    dockItem: {
        alignItems: 'center',
        justifyContent: 'center',
        height: '100%',
        flex: 1,
        position: 'relative',
    },
    inactiveIconContainer: {
        position: 'relative',
    },
    activeTabBackground: {
        width: 60,
        height: 60,
        borderRadius: 22,
        alignItems: 'center',
        justifyContent: 'center',
        elevation: 5,
        shadowColor: "#A855F7",
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.3,
        shadowRadius: 5,
    },
    dockLabel: {
        fontSize: 10,
        marginTop: 4,
        color: '#64748B',
        fontWeight: '500',
    },
    // NEW: Badge for notifications/daily rewards
    badge: {
        position: 'absolute',
        top: -2,
        right: -2,
        width: 10,
        height: 10,
        borderRadius: 5,
        backgroundColor: '#EF4444',
        borderWidth: 2,
        borderColor: 'white',
    },
});