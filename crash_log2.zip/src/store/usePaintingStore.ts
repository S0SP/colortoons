/**
 * Painting Progress Store
 * =======================
 * Saves user's painting progress for "Jump Back In" feature
 */

import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { mmkvStorage } from './mmkvStorage';

export interface SavedPainting {
    id: string;
    title: string;
    thumbnailB64: string;
    progress: number; // 0-1
    filledRegions: Record<number, boolean>;
    totalRegions: number;
    backendData: any; // Full backend response for resuming
    savedAt: number; // timestamp
    lastPlayedAt: number;
}

interface PaintingStore {
    savedPaintings: SavedPainting[];
    currentPaintingId: string | null;

    // Actions
    savePainting: (painting: Omit<SavedPainting, 'id' | 'savedAt'>) => string;
    updateProgress: (id: string, filledRegions: Record<number, boolean>, progress: number, thumbnailB64?: string) => void;
    deletePainting: (id: string) => void;
    getPainting: (id: string) => SavedPainting | undefined;
    setCurrentPainting: (id: string | null) => void;
    getRecentPaintings: (limit?: number) => SavedPainting[];
    clearAll: () => void;
}

export const usePaintingStore = create<PaintingStore>()(
    persist(
        (set, get) => ({
            savedPaintings: [],
            currentPaintingId: null,

            savePainting: (painting) => {
                const id = `painting_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
                const newPainting: SavedPainting = {
                    ...painting,
                    id,
                    savedAt: Date.now(),
                    lastPlayedAt: Date.now(),
                };

                set((state) => {
                    // Try to prevent SQLite Full errors by drastically reducing saved item count
                    const trimmedPaintings = [newPainting, ...state.savedPaintings].slice(0, 5);
                    return {
                        savedPaintings: trimmedPaintings,
                        currentPaintingId: id,
                    };
                });

                console.log('[PaintingStore] Saved painting:', id);
                return id;
            },

            updateProgress: (id, filledRegions, progress, thumbnailB64) => {
                set((state) => ({
                    savedPaintings: state.savedPaintings.map((p) =>
                        p.id === id
                            ? {
                                ...p,
                                filledRegions,
                                progress,
                                lastPlayedAt: Date.now(),
                                ...(thumbnailB64 ? { thumbnailB64 } : {})
                            }
                            : p
                    ),
                }));
            },

            deletePainting: (id) => {
                set((state) => ({
                    savedPaintings: state.savedPaintings.filter((p) => p.id !== id),
                    currentPaintingId: state.currentPaintingId === id ? null : state.currentPaintingId,
                }));
            },

            getPainting: (id) => {
                return get().savedPaintings.find((p) => p.id === id);
            },

            setCurrentPainting: (id) => {
                set({ currentPaintingId: id });
            },

            getRecentPaintings: (limit = 10) => {
                return [...get().savedPaintings]
                    .sort((a, b) => b.lastPlayedAt - a.lastPlayedAt)
                    .slice(0, limit);
            },

            clearAll: () => {
                set({ savedPaintings: [], currentPaintingId: null });
            },
        }),
        {
            name: 'painting-storage',
            storage: createJSONStorage(() => mmkvStorage),
        }
    )
);